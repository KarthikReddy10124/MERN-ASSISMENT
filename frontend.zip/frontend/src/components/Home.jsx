import { useEffect, useState } from "react";
import axios from "axios";

export default function Home() {
  const [blogs, setBlogs] = useState([]);
  const [form, setForm] = useState({
    title: "",
    content: "",
    author: "",
    category: "Technology",
  });

  useEffect(() => {
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    const response = await axios.get("http://localhost:4000/getBlogs");
    setBlogs(response.data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:4000/addblog", form);
    fetchBlogs();
    setForm({ title: "", content: "", author: "", category: "Technology" }); // Clear form after submit
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:4000/deleteblog/${id}`);
    fetchBlogs();
  };

  return (
    <div className="container mx-auto p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold text-center mb-6 text-blue-600">Blog List</h1>

      <form className="mb-6 bg-white p-6 rounded-lg shadow-lg" onSubmit={handleSubmit}>
        <input
          className="border p-3 w-full mb-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
          type="text"
          placeholder="Title"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          required
        />
        <textarea
          className="border p-3 w-full mb-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
          placeholder="Content"
          value={form.content}
          onChange={(e) => setForm({ ...form, content: e.target.value })}
          required
        ></textarea>
        <input
          className="border p-3 w-full mb-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
          type="text"
          placeholder="Author"
          value={form.author}
          onChange={(e) => setForm({ ...form, author: e.target.value })}
          required
        />
        <select
          className="border p-3 w-full mb-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
          required
        >
          {["Technology", "Health", "Lifestyle", "Education", "Travel", "Food", "Business"].map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <button className="bg-blue-500 text-white p-3 w-full rounded-md hover:bg-blue-600 transition">
          Add Blog
        </button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogs.map((blog) => (
          <div key={blog._id} className="border p-6 bg-white rounded-lg shadow-lg">
            <h2 className="text-xl font-bold text-gray-800">{blog.title}</h2>
            <p className="text-gray-600 mt-2">{blog.content}</p>
            <p className="text-sm text-gray-500 mt-2">By <span className="font-semibold">{blog.author}</span></p>
            <p className="text-xs text-gray-400 italic">Category: {blog.category}</p>
            <button
              className="bg-red-500 text-white p-2 mt-4 rounded-md hover:bg-red-600 transition"
              onClick={() => handleDelete(blog._id)}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
