import { useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

export default function DeleteBlog() {
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const deleteBlog = async () => {
      await axios.delete(`http://localhost:4000/deleteblog/${id}`);
      navigate("/");
    };
    deleteBlog();
  }, [id, navigate]);

  return (
    <div className="container mx-auto p-4 text-center">
      <h1 className="text-2xl font-bold text-red-600">Deleting Blog...</h1>
    </div>
  );
}
