import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function AddBlog() {
  const [form, setForm] = useState({
    title: "",
    content: "",
    author: "",
    category: "Technology",
  });
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:4000/addblog", form);
    navigate("/");
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Add a New Blog</h1>
      <form onSubmit={handleSubmit}>
        <input className="border p-2 w-full mb-2" type="text" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
        <textarea className="border p-2 w-full mb-2" placeholder="Content" value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} required></textarea>
        <input className="border p-2 w-full mb-2" type="text" placeholder="Author" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} required />
        <select className="border p-2 w-full mb-2" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} required>
          {["Technology", "Health", "Lifestyle", "Education", "Travel", "Food", "Business"].map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <button className="bg-blue-500 text-white p-2 w-full" type="submit">Add Blog</button>
      </form>
    </div>
  );
}
