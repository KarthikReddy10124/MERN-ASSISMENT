import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Login from "./components/Login";
import Home from "./components/Home";
import AddBlog from "./components/AddBlog";
import UpdateBlog from "./components/UpdateBlog";
import DeleteBlog from "./components/DeleteBlog";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <>
      <Navbar isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        <Route path="/add-blog" element={<AddBlog />} />
        <Route path="/update-blog/:id" element={<UpdateBlog />} />
        <Route path="/delete-blog/:id" element={<DeleteBlog />} />
      </Routes>
    
    </>
  );
}
