import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./index.css";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Login from "./components/Login";
import AddBlog from "./components/AddBlog";
import UpdateBlog from "./components/UpdateBlog";
import DeleteBlog from "./components/DeleteBlog";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <BrowserRouter>
      <Navbar isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        <Route path="/add-blog" element={<AddBlog />} />
        <Route path="/update-blog/:id" element={<UpdateBlog />} />
        <Route path="/delete-blog/:id" element={<DeleteBlog />} />
      </Routes>
    </BrowserRouter>
  );
}
